import 'vite/modulepreload-polyfill'
import '../web/product-card/scripts/product-card-main.js'
